import boto3
import json

def lambda_handler(event, context):
    sns_client = boto3.client('sns', 'us-east-1')
    topic_arn = 'arn:aws:sns:us-east-1:448641399641:FileShareNotificationTopic'

    try:
        json.dumps(event, indent=2)
        receiver_email = event['receiver_email']
        receiver_message = event['receiver_message']

        # Subscribe the receiver's email to the SNS topic
        sns_response = sns_client.subscribe(
            TopicArn=topic_arn,
            Protocol='email',
            Endpoint=receiver_email
        )

        # Send the email
        message = f"Hello,\n\nYou have received a shared file.\n\nMessage from sender: {receiver_message}"
        subject = "Shared File Notification"

        sns_client.publish(
            TopicArn=topic_arn,
            Message=message,
            Subject=subject
        )

        return {
            'statusCode': 200,
            'body': json.dumps('Email sent successfully!')
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
